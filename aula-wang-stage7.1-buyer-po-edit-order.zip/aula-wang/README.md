# AULA WANG - Website Jual Beli Hosting Minecraft

MVP deployable untuk jual beli hosting Minecraft dengan role **Owner** dan **Buyer**, pembayaran transfer manual, OCR bukti transfer gratis memakai Tesseract, REST API untuk bot WhatsApp/Discord, backup website, dan adapter integrasi Reviactyl/Pterodactyl API.

## Fitur Tahap 1

### Buyer
- Register/Login.
- Melihat paket hosting.
- Membeli paket hosting.
- Upload bukti pembayaran.
- Melihat status order/server.
- Riwayat transaksi sederhana via daftar order.
- Membuat tiket bantuan.

### Owner
- Dashboard statistik penjualan.
- Mengelola/menambah paket hosting.
- Melihat user.
- Melihat pesanan dan hasil OCR bukti transfer.
- Tombol **ACC & Buat Server**: server baru dibuat ke Reviactyl hanya setelah owner ACC.
- Reject pembayaran dengan catatan.
- Melihat tiket.

### Integrasi
- Sinkron akun website ke Reviactyl saat buyer register menggunakan Application API.
- Provision server Reviactyl saat owner ACC.
- REST API `/api/v1/*` dengan Bearer token untuk integrasi bot.
- Backup database + file upload ke folder lokal dan opsional Google Drive via rclone.

> Catatan: Reviactyl berbasis/kompatibel Pterodactyl API. Endpoint yang dipakai: `/api/application/users`, `/api/application/servers`, dan opsional `/api/client/servers/{identifier}/backups`. Jika versi panel Anda berbeda, adapter ada di `src/services/reviactyl.js`.

## Deploy cepat di VPS

1. Arahkan DNS domain/subdomain ke IP VPS.
2. Upload folder `aula-wang` ke VPS.
3. Jalankan:

```bash
cd aula-wang
bash scripts/install.sh
```

Installer akan menanyakan:
- Domain website.
- URL Reviactyl Panel.
- Reviactyl Application API Key.
- Email & password owner website.

Lalu Docker Compose akan menjalankan:
- `app` Node.js Fastify.
- `db` PostgreSQL.
- `caddy` reverse proxy HTTPS otomatis.

Buka `https://domain-anda`.

## Konfigurasi penting `.env`

```env
REVIACTYL_BASE_URL="https://panel.domainmu.com"
REVIACTYL_APPLICATION_API_KEY="ptla_xxx"
REVIACTYL_DEFAULT_LOCATION_ID=1
REVIACTYL_DEFAULT_NODE_ID=1
REVIACTYL_DEFAULT_NEST_ID=1
REVIACTYL_DEFAULT_EGG_ID=1
REVIACTYL_DEFAULT_DOCKER_IMAGE="ghcr.io/pterodactyl/yolks:java_21"
```

Untuk server creation otomatis, pastikan API key punya permission Application API yang cukup untuk user/server.

## Pembayaran manual + OCR

Buyer upload gambar bukti transfer. Sistem menjalankan OCR lokal gratis via Tesseract dan menyimpan:
- teks OCR mentah,
- confidence,
- apakah nominal invoice terdeteksi,
- petunjuk bank yang terbaca,
- rekomendasi untuk owner.

Owner **tetap wajib verifikasi mutasi rekening** sebelum ACC.

## REST API untuk bot WhatsApp/Discord

Health dan paket publik:

```bash
GET /api/v1/health
GET /api/v1/packages
```

Endpoint dengan token:

```bash
GET /api/v1/orders
POST /api/v1/orders
GET /api/v1/servers
GET /api/v1/tickets
```

Buat token bot:

```bash
bash scripts/create-api-token.sh discord-bot
```

Gunakan:

```bash
Authorization: Bearer aw_xxxxxxxxx
```

Contoh buat order dari bot:

```bash
curl -X POST https://domain/api/v1/orders \
  -H "Authorization: Bearer aw_xxx" \
  -H "Content-Type: application/json" \
  -d '{"user_email":"buyer@email.com","package_id":"UUID_PAKET","months":1,"type":"new"}'
```

## Backup

Backup manual:

```bash
bash scripts/backup.sh
```

Aktifkan backup otomatis ke Google Drive:

1. Setup rclone di VPS:
   ```bash
   rclone config
   ```
2. Pastikan remote sesuai `.env`, contoh:
   ```env
   BACKUP_ENABLED=true
   RCLONE_REMOTE="gdrive:aula-wang-backups"
   ```
3. Restart:
   ```bash
   docker compose restart app
   ```

## Backup server Reviactyl

Adapter sudah menyediakan fungsi `createBackup()` di `src/services/reviactyl.js`. Tahap berikutnya bisa ditambahkan tombol/scheduler backup server per-server di owner panel setelah Anda memastikan:
- Client API key tersedia,
- fitur backup aktif pada Reviactyl/Wings,
- opsi cloud storage Reviactyl didukung di panel Anda.

## Batasan MVP Tahap 1

Fitur berikut sudah disiapkan fondasinya tetapi belum diperdalam UI/logic penuh:
- Renew/upgrade resource server existing.
- Manajemen user detail oleh owner.
- Balas tiket dari owner.
- Scheduler expiry/suspend otomatis.
- Tombol backup server Reviactyl di UI.
- SMTP email notifikasi.
- Webhook bot WhatsApp/Discord khusus.

Saya menunggu ACC Anda untuk Tahap 2 sebelum menambahkan fitur-fitur lanjutan tersebut.


## Tahap 2 yang sudah ditambahkan

- Buyer dapat membuat order **perpanjang server existing** dari dashboard.
- Buyer dapat membuat order **upgrade paket/resource** dari dashboard.
- Owner ACC order `new`, `renew`, dan `upgrade`:
  - `new`: membuat server baru di Reviactyl.
  - `renew`: memperpanjang `expires_at` server lokal dan mencoba unsuspend server panel.
  - `upgrade`: mencoba update build/resource server via Application API, lalu mengganti paket lokal.
- Sistem lifecycle otomatis setiap 30 menit:
  - Server aktif yang lewat masa berlaku ditandai `expired`.
  - Jika `reviactyl_server_id` tersedia, sistem mencoba suspend server via Reviactyl API.
- Owner dapat melihat daftar server dan menekan tombol **Backup Panel** untuk membuat backup server via Client API Reviactyl.
- Tiket bantuan sekarang punya halaman detail, balasan buyer-owner, dan tombol tutup tiket untuk owner.
- Owner dapat mengubah role user buyer/owner.
- REST API ditambah:
  - `GET /api/v1/stats`
  - `GET /api/v1/users`
  - `POST /api/v1/users`
  - `POST /api/v1/servers/:id/renew-order`
  - `POST /api/v1/servers/:id/upgrade-order`

### Catatan penting Reviactyl Tahap 2

Untuk fitur backup server panel, isi juga:

```env
REVIACTYL_CLIENT_API_KEY="ptlc_xxx"
```

Untuk fitur upgrade resource, adapter memakai endpoint kompatibel Pterodactyl:

```http
PATCH /api/application/servers/{server}/build
```

Jika versi Reviactyl Anda memerlukan payload berbeda, ubah di:

```txt
src/services/reviactyl.js
```

## Tahap 3 yang sudah ditambahkan

### Owner panel lebih lengkap

- Edit paket hosting langsung dari tabel paket.
- Nonaktifkan paket hosting tanpa menghapus riwayat order lama.
- Update data user: nama, email, dan `reviactyl_user_id`.
- Ubah role buyer/owner.
- Melihat **Activity Log** untuk aktivitas penting seperti upload bukti, ACC order, reject, update paket, update user, dan request backup server.

### Invoice / print PDF

Setiap order punya halaman invoice:

```txt
/invoice/{order_id}
```

Buyer hanya bisa membuka invoice miliknya sendiri. Owner bisa membuka semua invoice. Tombol **Print / Simpan PDF** tersedia melalui fitur print browser.

### Public status page

Halaman status publik:

```txt
/status
```

Endpoint API publik:

```http
GET /api/v1/public-status
```

Bisa dimatikan dengan:

```env
PUBLIC_STATUS_ENABLED=false
```

### Notifikasi opsional

Sistem dapat mengirim notifikasi owner saat buyer upload bukti pembayaran dan saat tiket baru dibuat.

Konfigurasi `.env`:

```env
DISCORD_WEBHOOK_URL=""
WHATSAPP_WEBHOOK_URL=""
NOTIFY_OWNER_ON_PAYMENT=true
```

Untuk email SMTP:

```env
SMTP_HOST="smtp.example.com"
SMTP_PORT=587
SMTP_USER="user@example.com"
SMTP_PASS="password"
SMTP_FROM="AULA WANG <no-reply@example.com>"
```

Jika SMTP/webhook kosong, sistem tetap berjalan normal dan notifikasi akan dilewati.

### REST API tambahan Tahap 3

```http
GET /api/v1/public-status
GET /api/v1/activity-logs
```

`/api/v1/activity-logs` memerlukan Bearer token bot/admin.

### Installer lebih lengkap

`scripts/install.sh` sekarang menanyakan:

- Domain website.
- URL Reviactyl Panel.
- Application API key.
- Client API key untuk backup server.
- Default Location ID.
- Default Nest ID.
- Default Egg ID.
- Default Node ID.
- Bank pembayaran.
- Nomor rekening.
- Nama pemilik rekening.
- Email/password owner.

## Rekomendasi produksi

Sebelum membuka untuk publik:

1. Pastikan `SESSION_SECRET` dan `JWT_SECRET` sudah random kuat.
2. Pastikan API key Reviactyl hanya diberikan permission yang diperlukan.
3. Pastikan firewall VPS hanya membuka port 80/443 dan SSH.
4. Pastikan backup Google Drive/rclone sudah dites dengan `bash scripts/backup.sh`.
5. Verifikasi manual mutasi rekening sebelum menekan ACC, walaupun OCR menyatakan nominal cocok.

## Tahap 4 yang sudah ditambahkan

### Production hardening dasar

- Global rate limit via `@fastify/rate-limit`.
- Security headers via `@fastify/helmet`.
- Konfigurasi `.env`:

```env
RATE_LIMIT_MAX=180
RATE_LIMIT_WINDOW="1 minute"
LOGIN_RATE_LIMIT_MAX=10
```

> Catatan: rate limit global aktif untuk semua request. Jika trafik besar, naikkan `RATE_LIMIT_MAX` sesuai kebutuhan.

### Kontrol server Reviactyl dari owner panel

Owner panel sekarang punya aksi tambahan per server:

- Lihat `Status JSON`.
- Backup server panel.
- Power action:
  - Start
  - Restart
  - Stop
  - Kill
- Suspend.
- Unsuspend.
- Reinstall.
- Delete remote server, dengan konfirmasi teks `DELETE`.

Endpoint Reviactyl yang dipakai:

```http
GET  /api/application/servers/{server}
GET  /api/client/servers/{identifier}/resources
POST /api/client/servers/{identifier}/power
POST /api/application/servers/{server}/suspend
POST /api/application/servers/{server}/unsuspend
POST /api/application/servers/{server}/reinstall
DELETE /api/application/servers/{server}
DELETE /api/application/servers/{server}/force
```

Fitur resources/power/backup membutuhkan:

```env
REVIACTYL_CLIENT_API_KEY="ptlc_xxx"
```

### Status server API

Buyer dan owner bisa membuka status JSON server:

```txt
/servers/{server_id}/status.json
```

REST API untuk bot:

```http
GET  /api/v1/servers/{id}/status
POST /api/v1/servers/{id}/power
POST /api/v1/servers/{id}/suspend
POST /api/v1/servers/{id}/unsuspend
```

Semua endpoint `/api/v1/servers/{id}/*` membutuhkan Bearer token.

### Backup website dari owner panel

Owner panel sekarang punya tombol:

```txt
Backup Website Sekarang
```

Tombol ini menjalankan:

```bash
bash scripts/backup.sh
```

Jika `BACKUP_ENABLED=true` dan rclone remote sudah disiapkan, backup juga dikirim ke Google Drive.

### Export sales CSV

Owner panel punya tombol:

```txt
Export Sales CSV
```

Endpoint:

```txt
/owner/reports/sales.csv
```

File CSV berisi invoice, tipe order, nominal, status, tanggal, email buyer, dan nama paket.

## Catatan keamanan Tahap 4

- Fitur delete server bersifat destructive. Gunakan hanya jika benar-benar perlu.
- Fitur power/reinstall/delete sangat bergantung pada permission API key Reviactyl.
- Jika endpoint Reviactyl versi Anda berbeda, sesuaikan adapter di:

```txt
src/services/reviactyl.js
```

- Untuk production yang ramai, disarankan tambah Cloudflare/WAF di depan VPS.

## Tahap 5 - Ocean Blue UX Update

Perubahan fokus ke tampilan dan keterikatan flow transaksi:

- Theme baru Ocean Blue untuk seluruh UI.
- Dashboard buyer dipisah menjadi:
  - instruksi pembayaran,
  - order yang perlu upload bukti,
  - order menunggu ACC owner,
  - server aktif,
  - riwayat order.
- Setelah buyer klik beli paket, langsung diarahkan ke halaman detail order `/orders/{id}`.
- Halaman detail order menampilkan:
  - ringkasan paket,
  - total bayar,
  - rekening pembayaran,
  - form upload bukti pembayaran,
  - progress order,
  - tombol print invoice.
- Owner panel diprioritaskan ke antrian bukti pembayaran:
  - bukti transfer,
  - OCR/AI review,
  - tombol ACC & Proses Server,
  - tombol reject dengan catatan.
- Route API sudah dipatch agar format Fastify benar, mencegah error `FST_ERR_ROUTE_MISSING_HANDLER`.

## Tahap 6 - Buyer pilih Egg/Software Minecraft

Perubahan:

- Halaman beli paket sekarang punya pilihan **Software / Egg Minecraft**.
- Daftar Egg otomatis dicoba diambil dari Reviactyl Application API:

```http
GET /api/application/nests/{REVIACTYL_DEFAULT_NEST_ID}/eggs
```

- Jika API egg gagal/kosong, sistem fallback ke `REVIACTYL_DEFAULT_EGG_ID` dari `.env`.
- Saat buyer order, sistem menyimpan ke database:
  - `reviactyl_nest_id`
  - `reviactyl_egg_id`
  - `reviactyl_egg_name`
  - `reviactyl_environment`
- Saat owner ACC, server dibuat memakai egg yang dipilih buyer.
- Buyer juga bisa isi:
  - Minecraft Version
  - Build Type

### Manual whitelist Egg

Kalau endpoint list egg Reviactyl Anda tidak cocok, isi manual di `.env`:

```env
REVIACTYL_ALLOWED_EGGS_JSON='[{"nest_id":1,"egg_id":5,"name":"Paper"},{"nest_id":1,"egg_id":6,"name":"Vanilla"},{"nest_id":1,"egg_id":7,"name":"Spigot"}]'
```

### Variable egg tambahan

Kalau Egg masih minta variable lain, isi:

```env
REVIACTYL_EXTRA_ENV_JSON='{"DL_VERSION":"latest","BUILD_TYPE":"paper"}'
```

## Tahap 7 - Multi Node Routing + PO Khusus

Perubahan:

- Owner panel menampilkan **Monitor Node Reviactyl** dari Application API:
  - Node ID
  - nama node
  - FQDN
  - memory
  - disk
  - upload limit
  - maintenance mode
- Pada antrian bukti pembayaran, owner bisa mengarahkan order ke node tertentu sebelum ACC.
- Owner bisa isi Allocation ID opsional. Jika kosong, sistem mencoba mengambil allocation kosong dari node terpilih.
- Saat ACC order, server dibuat sesuai node/allocation yang dipilih owner.
- Buyer bisa membuat **PO / Pesanan Khusus** untuk kebutuhan seperti:
  - private node
  - PV node
  - dedicated resource
  - setup server custom
- Owner bisa review dan update status PO khusus:
  - requested
  - reviewing
  - quoted
  - approved
  - rejected
  - completed

Catatan permission API key Reviactyl:

- Untuk monitor node: butuh permission read nodes.
- Untuk auto allocation pada node: butuh permission read allocations node.

## Patch Tahap 7.1 - Buyer PO + Edit Order Gagal

Perbaikan:

- Dashboard buyer sekarang menampilkan bagian PO/Pesanan Khusus secara jelas di dekat atas halaman.
- Buyer bisa membuat PO untuk PV node/private node/custom setup.
- Buyer bisa melihat riwayat PO dan catatan owner.
- Order dengan status `pending_payment`, `rejected`, atau `failed` sekarang bisa diedit buyer dari halaman detail order.
- Edit order mendukung:
  - ganti paket,
  - ganti egg/software,
  - ganti Minecraft version,
  - ganti build type,
  - ganti durasi.
- Setelah order diedit, status kembali ke `pending_payment`, catatan error owner dibersihkan, dan buyer bisa upload bukti ulang.
