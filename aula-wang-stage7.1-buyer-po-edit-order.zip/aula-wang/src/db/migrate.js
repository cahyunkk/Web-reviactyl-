import { q, pool } from './pool.js';
const sql = `
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'buyer' CHECK(role IN ('owner','buyer')), reviactyl_user_id TEXT, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS packages (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', price_monthly INTEGER NOT NULL,
 memory_mb INTEGER NOT NULL, disk_mb INTEGER NOT NULL, cpu_percent INTEGER NOT NULL, backups INTEGER NOT NULL DEFAULT 1, databases INTEGER NOT NULL DEFAULT 0,
 is_active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS orders (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), invoice_no TEXT UNIQUE NOT NULL, user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 package_id UUID REFERENCES packages(id), type TEXT NOT NULL CHECK(type IN ('new','renew','upgrade')), months INTEGER NOT NULL DEFAULT 1, amount INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending_payment' CHECK(status IN ('pending_payment','payment_uploaded','approved','rejected','provisioning','active','failed','expired')),
 payment_proof_path TEXT, ocr_text TEXT, ocr_analysis JSONB DEFAULT '{}'::jsonb, owner_note TEXT, server_id UUID, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS servers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id) ON DELETE CASCADE, package_id UUID REFERENCES packages(id), order_id UUID REFERENCES orders(id),
 name TEXT NOT NULL, reviactyl_server_id TEXT, reviactyl_identifier TEXT, status TEXT NOT NULL DEFAULT 'pending', expires_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='orders_server_fk') THEN
  ALTER TABLE orders ADD CONSTRAINT orders_server_fk FOREIGN KEY (server_id) REFERENCES servers(id) DEFERRABLE INITIALLY DEFERRED;
 END IF;
END $$;
CREATE TABLE IF NOT EXISTS transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id) ON DELETE CASCADE, order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
 type TEXT NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL, metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS tickets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id) ON DELETE CASCADE, subject TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS ticket_messages (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), ticket_id UUID REFERENCES tickets(id) ON DELETE CASCADE, user_id UUID REFERENCES users(id) ON DELETE CASCADE, message TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS api_tokens (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, token_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'bot', created_at TIMESTAMPTZ DEFAULT now(), last_used_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_servers_user ON servers(user_id);

ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviactyl_nest_id INTEGER;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviactyl_egg_id INTEGER;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviactyl_egg_name TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviactyl_environment JSONB DEFAULT '{}'::jsonb;


CREATE TABLE IF NOT EXISTS activity_logs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id) ON DELETE SET NULL,
 action TEXT NOT NULL, entity_type TEXT NOT NULL DEFAULT '', entity_id TEXT, metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_activity_logs_created ON activity_logs(created_at DESC);

ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviactyl_node_id INTEGER;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviactyl_allocation_id INTEGER;

CREATE TABLE IF NOT EXISTS special_orders (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 description TEXT NOT NULL,
 budget INTEGER DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested','reviewing','quoted','approved','rejected','completed')),
 owner_note TEXT,
 created_at TIMESTAMPTZ DEFAULT now(),
 updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_special_orders_user ON special_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_special_orders_status ON special_orders(status);


`;
await q(sql);
console.log('Migration completed');
await pool.end();
