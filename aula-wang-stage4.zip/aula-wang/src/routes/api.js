import bcrypt from 'bcryptjs';
import { q } from '../db/pool.js';
import { requireApiToken } from '../middleware/auth.js';
import { invoiceNo } from '../utils/format.js';
import * as reviactyl from '../services/reviactyl.js';
import { audit } from '../services/audit.js';

export async function apiRoutes(app) {
  app.get('/api/v1/health', async () => ({ ok:true, name:'AULA WANG' }));
  app.get('/api/v1/packages', async () => (await q('SELECT * FROM packages WHERE is_active=true ORDER BY price_monthly')).rows);

  app.get('/api/v1/public-status', async (req, reply) => {
    reply.send((await q(`SELECT s.name,s.status,s.expires_at,s.reviactyl_identifier,p.name package_name FROM servers s LEFT JOIN packages p ON p.id=s.package_id WHERE s.status IN ('active','expired') ORDER BY s.created_at DESC LIMIT 100`)).rows);
  });


  app.get('/api/v1/stats', { preHandler: requireApiToken(async (req, reply) => {
    const stats = (await q(`SELECT count(*) FILTER (WHERE status='active') active_servers, count(*) orders, coalesce(sum(amount) FILTER (WHERE status IN ('approved','active')),0) revenue FROM orders`)).rows[0];
    reply.send(stats);
  }) });

  app.get('/api/v1/users', { preHandler: requireApiToken(async (req, reply) => reply.send((await q('SELECT id,name,email,role,reviactyl_user_id,created_at FROM users ORDER BY created_at DESC LIMIT 200')).rows)) });

  app.post('/api/v1/users', { preHandler: requireApiToken(async (req, reply) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password || String(password).length < 8) return reply.code(400).send({ error:'name, email, password min 8 required' });
    const hash = await bcrypt.hash(password, 12);
    const user = (await q('INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,name,email,role,reviactyl_user_id', [name, String(email).toLowerCase(), hash, 'buyer'])).rows[0];
    try { const rid = await reviactyl.createUser(user, password); if (rid) { await q('UPDATE users SET reviactyl_user_id=$1 WHERE id=$2', [String(rid), user.id]); user.reviactyl_user_id = String(rid); } } catch(e) { app.log.warn(e, 'api user sync failed'); }
    reply.send(user);
  }) });

  app.get('/api/v1/orders', { preHandler: requireApiToken(async (req, reply) => reply.send((await q('SELECT o.*,u.email,p.name package_name FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id ORDER BY o.created_at DESC LIMIT 200')).rows)) });

  app.post('/api/v1/orders', { preHandler: requireApiToken(async (req, reply) => {
    const { user_email, package_id, months=1, type='new', server_id=null } = req.body;
    const user=(await q('SELECT * FROM users WHERE email=$1',[String(user_email||'').toLowerCase()])).rows[0];
    const pkg=(await q('SELECT * FROM packages WHERE id=$1',[package_id])).rows[0];
    if(!user||!pkg) return reply.code(404).send({error:'user/package not found'});
    const safeType = ['new','renew','upgrade'].includes(type) ? type : 'new';
    const amount=pkg.price_monthly*Number(months); const inv=invoiceNo();
    const order=(await q('INSERT INTO orders(invoice_no,user_id,package_id,type,months,amount,server_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[inv,user.id,pkg.id,safeType,months,amount,server_id])).rows[0];
    return reply.send(order);
  }) });

  app.get('/api/v1/servers', { preHandler: requireApiToken(async (req, reply) => reply.send((await q('SELECT s.*,u.email,p.name package_name FROM servers s JOIN users u ON u.id=s.user_id LEFT JOIN packages p ON p.id=s.package_id ORDER BY s.created_at DESC LIMIT 200')).rows)) });

  app.post('/api/v1/servers/:id/renew-order', { preHandler: requireApiToken(async (req, reply) => {
    const srv=(await q('SELECT s.*,p.price_monthly FROM servers s JOIN packages p ON p.id=s.package_id WHERE s.id=$1',[req.params.id])).rows[0];
    if(!srv) return reply.code(404).send({error:'server not found'});
    const months=Math.max(1, Math.min(12, Number(req.body.months)||1));
    const order=(await q('INSERT INTO orders(invoice_no,user_id,package_id,type,months,amount,server_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[invoiceNo(),srv.user_id,srv.package_id,'renew',months,srv.price_monthly*months,srv.id])).rows[0];
    reply.send(order);
  }) });

  app.post('/api/v1/servers/:id/upgrade-order', { preHandler: requireApiToken(async (req, reply) => {
    const srv=(await q('SELECT * FROM servers WHERE id=$1',[req.params.id])).rows[0];
    const pkg=(await q('SELECT * FROM packages WHERE id=$1',[req.body.package_id])).rows[0];
    if(!srv || !pkg) return reply.code(404).send({error:'server/package not found'});
    const months=Math.max(1, Math.min(12, Number(req.body.months)||1));
    const order=(await q('INSERT INTO orders(invoice_no,user_id,package_id,type,months,amount,server_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[invoiceNo(),srv.user_id,pkg.id,'upgrade',months,pkg.price_monthly*months,srv.id])).rows[0];
    reply.send(order);
  }) });

  app.get('/api/v1/servers/:id/status', { preHandler: requireApiToken(async (req, reply) => {
    const srv=(await q('SELECT * FROM servers WHERE id=$1',[req.params.id])).rows[0];
    if(!srv) return reply.code(404).send({error:'server not found'});
    const out={ local:srv, application:null, resources:null, errors:[] };
    if(srv.reviactyl_server_id) { try { out.application=await reviactyl.getServer(srv.reviactyl_server_id); } catch(e) { out.errors.push(e.message); } }
    if(srv.reviactyl_identifier) { try { out.resources=await reviactyl.getServerResources(srv.reviactyl_identifier); } catch(e) { out.errors.push(e.message); } }
    reply.send(out);
  }) });

  app.post('/api/v1/servers/:id/power', { preHandler: requireApiToken(async (req, reply) => {
    const srv=(await q('SELECT * FROM servers WHERE id=$1',[req.params.id])).rows[0];
    if(!srv) return reply.code(404).send({error:'server not found'});
    const signal=String(req.body.signal||'restart');
    if(!srv.reviactyl_identifier) return reply.code(400).send({error:'missing reviactyl identifier'});
    await reviactyl.powerAction(srv.reviactyl_identifier, signal);
    await audit(null, 'api_server_power_action', 'server', srv.id, { signal });
    reply.send({ ok:true, signal });
  }) });

  app.post('/api/v1/servers/:id/suspend', { preHandler: requireApiToken(async (req, reply) => {
    const srv=(await q('SELECT * FROM servers WHERE id=$1',[req.params.id])).rows[0];
    if(!srv) return reply.code(404).send({error:'server not found'});
    if(srv.reviactyl_server_id) await reviactyl.suspendServer(srv.reviactyl_server_id);
    await q("UPDATE servers SET status='suspended', updated_at=now() WHERE id=$1", [srv.id]);
    reply.send({ ok:true });
  }) });

  app.post('/api/v1/servers/:id/unsuspend', { preHandler: requireApiToken(async (req, reply) => {
    const srv=(await q('SELECT * FROM servers WHERE id=$1',[req.params.id])).rows[0];
    if(!srv) return reply.code(404).send({error:'server not found'});
    if(srv.reviactyl_server_id) await reviactyl.unsuspendServer(srv.reviactyl_server_id);
    await q("UPDATE servers SET status='active', updated_at=now() WHERE id=$1", [srv.id]);
    reply.send({ ok:true });
  }) });

  app.get('/api/v1/tickets', { preHandler: requireApiToken(async (req, reply) => reply.send((await q('SELECT t.*,u.email FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.created_at DESC LIMIT 200')).rows)) });

  app.get('/api/v1/activity-logs', { preHandler: requireApiToken(async (req, reply) => reply.send((await q('SELECT l.*,u.email FROM activity_logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT 200')).rows)) });

}
