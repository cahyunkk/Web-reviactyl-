# Upload AULA WANG ke GitHub lalu deploy di VPS

## Jangan upload file rahasia

File yang aman di-upload ke GitHub:
- source code
- Dockerfile
- docker-compose.yml
- .env.example

File yang tidak boleh di-upload:
- .env
- API key Reviactyl
- token bot
- password database
- bukti pembayaran user
- folder uploads
- folder backups

Semua itu sudah dicegah oleh `.gitignore`.

## Cara upload ke GitHub lewat website

1. Buka https://github.com/new
2. Buat repository baru, contoh:
   `aula-wang-hosting`
3. Pilih Private jika tidak ingin publik.
4. Jangan centang README/gitignore/license, karena project sudah punya file sendiri.
5. Setelah repo dibuat, upload isi folder `aula-wang`, bukan folder zip-nya.

## Cara upload pakai Git dari laptop

Masuk folder project:

```bash
cd aula-wang
```

Init git:

```bash
git init
git add .
git commit -m "Initial AULA WANG hosting website"
```

Hubungkan ke repo GitHub:

```bash
git branch -M main
git remote add origin https://github.com/USERNAME/aula-wang-hosting.git
git push -u origin main
```

Ganti `USERNAME` dengan username GitHub Anda.

## Deploy dari GitHub ke VPS tanpa root folder

Login SSH ke VPS sebagai user biasa:

```bash
ssh username@IP_VPS
```

Clone ke home user:

```bash
cd ~
git clone https://github.com/USERNAME/aula-wang-hosting.git aula-wang
cd aula-wang
```

Buat `.env`:

```bash
cp .env.example .env
nano .env
```

Isi domain, API key Reviactyl, payment, dan lain-lain.

Jalankan:

```bash
docker compose up -d --build
```

Jika `docker` tidak bisa dipakai user biasa, minta provider/VPS admin untuk memasukkan user ke docker group:

```bash
sudo usermod -aG docker $USER
```

Lalu logout-login SSH lagi.

## Update website setelah ada perubahan

Di VPS:

```bash
cd ~/aula-wang
git pull
docker compose up -d --build
```
