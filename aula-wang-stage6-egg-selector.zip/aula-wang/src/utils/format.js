export const rupiah = n => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(n||0));
export const dateID = d => d ? new Intl.DateTimeFormat('id-ID',{dateStyle:'medium', timeStyle:'short'}).format(new Date(d)) : '-';
export const invoiceNo = () => 'AW-' + new Date().toISOString().slice(0,10).replaceAll('-','') + '-' + Math.random().toString(36).slice(2,8).toUpperCase();
