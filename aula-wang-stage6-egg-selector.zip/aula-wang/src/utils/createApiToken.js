import { randomBytes, createHash } from 'node:crypto';
import { q, pool } from '../db/pool.js';
const name = process.argv[2] || 'bot-integration';
const token = 'aw_' + randomBytes(32).toString('hex');
const hash = createHash('sha256').update(token).digest('hex');
await q('INSERT INTO api_tokens(name,token_hash,role) VALUES($1,$2,$3)', [name, hash, 'bot']);
console.log('Simpan token ini, tidak bisa dilihat lagi:');
console.log(token);
await pool.end();
