import bcrypt from 'bcryptjs';
import { q, pool } from './pool.js';
import { config } from '../config.js';
const ownerHash = await bcrypt.hash(config.ownerPassword, 12);
await q(`INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,'owner') ON CONFLICT(email) DO NOTHING`, [config.ownerName, config.ownerEmail.toLowerCase(), ownerHash]);
const count = await q('SELECT count(*)::int c FROM packages');
if (count.rows[0].c === 0) {
  await q(`INSERT INTO packages(name,description,price_monthly,memory_mb,disk_mb,cpu_percent,backups,databases) VALUES
  ('Grass 1GB','Paket awal Minecraft untuk survival kecil.',15000,1024,5120,100,1,0),
  ('Iron 2GB','Untuk komunitas kecil dan plugin ringan.',30000,2048,10240,150,2,1),
  ('Diamond 4GB','Untuk server publik menengah.',60000,4096,20480,200,3,2)`);
}
console.log('Seed completed');
await pool.end();
