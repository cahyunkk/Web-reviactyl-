import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { q } from '../db/pool.js';
export async function attachUser(req) {
  req.user = null;
  const token = req.cookies?.aw_session;
  if (!token) return;
  try {
    const payload = jwt.verify(token, config.sessionSecret);
    const res = await q('SELECT id,name,email,role,reviactyl_user_id FROM users WHERE id=$1', [payload.uid]);
    req.user = res.rows[0] || null;
  } catch {}
}
export function signSession(reply, user) {
  const token = jwt.sign({ uid:user.id, role:user.role }, config.sessionSecret, { expiresIn:'7d' });
  reply.setCookie('aw_session', token, { httpOnly:true, sameSite:'lax', secure: process.env.NODE_ENV === 'production', path:'/', maxAge: 60*60*24*7 });
}
export function clearSession(reply) { reply.clearCookie('aw_session', { path:'/' }); }
export async function requireAuth(req, reply) { if (!req.user) return reply.redirect('/login'); }
export async function requireOwner(req, reply) { if (!req.user) return reply.redirect('/login'); if (req.user.role !== 'owner') return reply.code(403).send('Forbidden'); }
export function requireApiToken(handler) { return async (req, reply) => {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) return reply.code(401).send({ error:'Missing bearer token' });
  const crypto = await import('node:crypto');
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const res = await q('SELECT * FROM api_tokens WHERE token_hash=$1', [hash]);
  if (!res.rows[0]) return reply.code(401).send({ error:'Invalid token' });
  await q('UPDATE api_tokens SET last_used_at=now() WHERE id=$1', [res.rows[0].id]);
  req.apiToken = res.rows[0];
  return handler(req, reply);
}; }
