import cron from 'node-cron';
import { exec } from 'node:child_process';
import { config } from '../config.js';
export function scheduleBackups(app) {
  if (!config.backup.enabled) return;
  cron.schedule(config.backup.cron, () => {
    exec('bash scripts/backup.sh', { cwd: process.cwd() }, (err, stdout, stderr) => app.log.info({ err: err?.message, stdout, stderr }, 'backup job finished'));
  });
}
