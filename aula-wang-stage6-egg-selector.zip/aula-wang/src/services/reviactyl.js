import { config } from '../config.js';

async function api(path, { method='GET', body, keyType='application' } = {}) {
  if (!config.reviactyl.enabled) return { mocked: true, data: null };
  const key = keyType === 'client' ? config.reviactyl.clientKey : config.reviactyl.appKey;
  if (!config.reviactyl.baseUrl || !key) throw new Error('Reviactyl API belum dikonfigurasi');
  const res = await fetch(`${config.reviactyl.baseUrl}${path}`, {
    method,
    headers: { 'Authorization': `Bearer ${key}`, 'Accept': 'application/json', 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  let json; try { json = text ? JSON.parse(text) : null; } catch { json = { raw: text }; }
  if (!res.ok) throw new Error(`Reviactyl API ${method} ${path} gagal ${res.status}: ${text.slice(0,500)}`);
  return json;
}

function parseExtraEnv() {
  try { return JSON.parse(process.env.REVIACTYL_EXTRA_ENV_JSON || '{}'); } catch { return {}; }
}

export function defaultEggOption() {
  return { nest_id: config.reviactyl.nestId, egg_id: config.reviactyl.eggId, name: `Default Egg #${config.reviactyl.eggId}`, description: 'Default dari .env', docker_image: config.reviactyl.image, startup: config.reviactyl.startup };
}

export async function listAvailableEggs() {
  // Fallback manual dari .env. Format:
  // REVIACTYL_ALLOWED_EGGS_JSON=[{"nest_id":1,"egg_id":5,"name":"Paper"},{"nest_id":1,"egg_id":6,"name":"Vanilla"}]
  try {
    const manual = JSON.parse(process.env.REVIACTYL_ALLOWED_EGGS_JSON || '[]');
    if (Array.isArray(manual) && manual.length) return manual.map(e => ({ nest_id:Number(e.nest_id || config.reviactyl.nestId), egg_id:Number(e.egg_id || e.id), name:e.name || `Egg #${e.egg_id || e.id}`, description:e.description || '', docker_image:e.docker_image || config.reviactyl.image, startup:e.startup || config.reviactyl.startup }));
  } catch {}

  try {
    const json = await api(`/api/application/nests/${config.reviactyl.nestId}/eggs`);
    const data = Array.isArray(json?.data) ? json.data : [];
    const eggs = data.map(item => {
      const a = item.attributes || item;
      return { nest_id: config.reviactyl.nestId, egg_id:Number(a.id), name:a.name || `Egg #${a.id}`, description:a.description || '', docker_image:a.docker_image || config.reviactyl.image, startup:a.startup || config.reviactyl.startup };
    }).filter(e => e.egg_id);
    return eggs.length ? eggs : [defaultEggOption()];
  } catch {
    return [defaultEggOption()];
  }
}

export async function findEggOption(eggId) {
  const eggs = await listAvailableEggs();
  return eggs.find(e => Number(e.egg_id) === Number(eggId)) || defaultEggOption();
}

export async function createUser(user, plainPassword) {
  const payload = { email: user.email, username: user.email.split('@')[0].replace(/[^a-zA-Z0-9_.-]/g,'').slice(0,32) || 'user', first_name: user.name.split(' ')[0] || 'Buyer', last_name: user.name.split(' ').slice(1).join(' ') || 'AULA', password: plainPassword, root_admin: false, language: 'en' };
  const json = await api('/api/application/users', { method:'POST', body: payload });
  return json?.attributes?.id || json?.data?.attributes?.id || json?.id || null;
}

export async function createServer({ user, pkg, order }) {
  const limits = { memory: pkg.memory_mb, swap: 0, disk: pkg.disk_mb, io: 500, cpu: pkg.cpu_percent };
  const feature_limits = { databases: pkg.databases, backups: pkg.backups, allocations: 1 };
  const selectedEggId = Number(order?.reviactyl_egg_id || config.reviactyl.eggId);
  const selectedEgg = order?.reviactyl_egg_id ? await findEggOption(selectedEggId) : defaultEggOption();
  const orderEnv = order?.reviactyl_environment && typeof order.reviactyl_environment === 'object' ? order.reviactyl_environment : {};
  const mcVersion = orderEnv.MINECRAFT_VERSION || process.env.REVIACTYL_MINECRAFT_VERSION || 'latest';
  const buildType = orderEnv.BUILD_TYPE || process.env.REVIACTYL_BUILD_TYPE || 'paper';
  const buildNumber = orderEnv.BUILD_NUMBER || process.env.REVIACTYL_BUILD_NUMBER || 'latest';

  const environment = {
    SERVER_JARFILE: process.env.REVIACTYL_SERVER_JARFILE || 'server.jar',
    SERVER_MEMORY: String(pkg.memory_mb),
    EULA: 'TRUE',
    MINECRAFT_VERSION: mcVersion,
    VERSION: mcVersion,
    MC_VERSION: mcVersion,
    SERVER_VERSION: mcVersion,
    VANILLA_VERSION: mcVersion,
    PAPER_VERSION: mcVersion,
    BUILD_NUMBER: buildNumber,
    BUILD_VERSION: buildNumber,
    BUILD_TYPE: buildType,
    SERVER_TYPE: buildType,
    TYPE: buildType,
    SOFTWARE: buildType,
    SERVER_SOFTWARE: buildType,
    ...parseExtraEnv(),
    ...orderEnv
  };
  const allocation = config.reviactyl.allocationId ? { default: Number(config.reviactyl.allocationId) } : undefined;
  const payload = { name: `${user.name} - ${pkg.package_name || pkg.name}`, user: Number(user.reviactyl_user_id), egg: selectedEggId, docker_image: selectedEgg.docker_image || config.reviactyl.image, startup: selectedEgg.startup || config.reviactyl.startup, environment, limits, feature_limits, deploy: allocation ? undefined : { locations: [Number(order?.reviactyl_location_id || config.reviactyl.locationId)], dedicated_ip: false, port_range: [] }, allocation, start_on_completion: true };
  const json = await api('/api/application/servers', { method:'POST', body: payload });
  const attr = json?.attributes || json?.data?.attributes || json;
  return { id: attr?.id, identifier: attr?.identifier };
}

export async function getServer(serverId) { return api(`/api/application/servers/${serverId}`); }
export async function createBackup(clientServerIdentifier) { return api(`/api/client/servers/${clientServerIdentifier}/backups`, { method:'POST', keyType:'client', body: { name: `AULA-WANG-${Date.now()}` } }); }
export async function updateServerBuild(serverId, pkg) {
  const details = await api(`/api/application/servers/${serverId}`);
  const attr = details?.attributes || details?.data?.attributes || details || {};
  const allocation = attr.allocation || attr.allocation_id || attr.relationships?.allocations?.data?.find?.(a => a.attributes?.default)?.attributes?.id;
  const body = { allocation: Number(allocation || config.reviactyl.allocationId || 0) || undefined, memory: pkg.memory_mb, swap: 0, disk: pkg.disk_mb, io: 500, cpu: pkg.cpu_percent, threads: null, feature_limits: { databases: pkg.databases, backups: pkg.backups, allocations: 1 } };
  return api(`/api/application/servers/${serverId}/build`, { method:'PATCH', body });
}
export async function suspendServer(serverId) { return api(`/api/application/servers/${serverId}/suspend`, { method:'POST' }); }
export async function unsuspendServer(serverId) { return api(`/api/application/servers/${serverId}/unsuspend`, { method:'POST' }); }
export async function deleteServer(serverId) { return api(`/api/application/servers/${serverId}`, { method:'DELETE' }); }
export async function getServerResources(clientServerIdentifier) { return api(`/api/client/servers/${clientServerIdentifier}/resources`, { keyType:'client' }); }
export async function powerAction(clientServerIdentifier, signal) { if (!['start','stop','restart','kill'].includes(signal)) throw new Error('Power signal tidak valid'); return api(`/api/client/servers/${clientServerIdentifier}/power`, { method:'POST', keyType:'client', body:{ signal } }); }
export async function reinstallServer(serverId) { return api(`/api/application/servers/${serverId}/reinstall`, { method:'POST' }); }
export async function forceDeleteServer(serverId) { return api(`/api/application/servers/${serverId}/force`, { method:'DELETE' }); }
