import cron from 'node-cron';
import { q } from '../db/pool.js';
import * as reviactyl from './reviactyl.js';

export function scheduleLifecycle(app) {
  cron.schedule('*/30 * * * *', async () => {
    try {
      const expired = await q(`UPDATE servers SET status='expired', updated_at=now() WHERE status='active' AND expires_at IS NOT NULL AND expires_at < now() RETURNING id,name,reviactyl_server_id`);
      for (const srv of expired.rows) {
        if (srv.reviactyl_server_id) {
          try { await reviactyl.suspendServer(srv.reviactyl_server_id); } catch (e) { app.log.warn(e, `suspend failed for ${srv.id}`); }
        }
      }
      if (expired.rows.length) app.log.info({ expired: expired.rows }, 'servers marked expired');
    } catch (e) { app.log.error(e, 'lifecycle job failed'); }
  });
}
