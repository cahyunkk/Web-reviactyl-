import nodemailer from 'nodemailer';
import { config } from '../config.js';

function smtpReady() { return !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS); }
export async function sendEmail({ to, subject, text }) {
  if (!smtpReady() || !to) return { skipped:true };
  const transporter = nodemailer.createTransport({ host:process.env.SMTP_HOST, port:Number(process.env.SMTP_PORT||587), secure:Number(process.env.SMTP_PORT||587)===465, auth:{ user:process.env.SMTP_USER, pass:process.env.SMTP_PASS } });
  return transporter.sendMail({ from:process.env.SMTP_FROM || `AULA WANG <no-reply@${new URL(config.appUrl).hostname}>`, to, subject, text });
}
async function postWebhook(url, payload) {
  if (!url) return { skipped:true };
  const body = url.includes('discord') ? { content: payload.text, embeds: payload.embed ? [payload.embed] : undefined } : payload;
  const res = await fetch(url, { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(body) });
  if (!res.ok) throw new Error(`Webhook gagal ${res.status}: ${await res.text()}`);
  return { ok:true };
}
export async function notifyOwner(app, title, text, fields={}) {
  const payload = { text:`**${title}**\n${text}`, embed:{ title, description:text, fields:Object.entries(fields).map(([name,value])=>({ name, value:String(value), inline:true })) } };
  for (const url of [process.env.DISCORD_WEBHOOK_URL, process.env.WHATSAPP_WEBHOOK_URL]) {
    try { await postWebhook(url, payload); } catch(e) { app?.log?.warn(e, 'webhook notify failed'); }
  }
  try { await sendEmail({ to:config.ownerEmail, subject:`[AULA WANG] ${title}`, text:`${text}\n\n${JSON.stringify(fields,null,2)}` }); } catch(e) { app?.log?.warn(e, 'email notify failed'); }
}
