import { createWorker } from 'tesseract.js';
import { config } from '../config.js';
export async function analyzePaymentProof(filePath, expectedAmount) {
  if (!config.ocr.enabled) return { text: '', analysis: { status:'disabled', confidence:0, message:'OCR dimatikan' } };
  try {
    const worker = await createWorker(config.ocr.lang);
    const { data } = await worker.recognize(filePath);
    await worker.terminate();
    const text = data.text || '';
    const normalized = text.replace(/[.,\s]/g,'');
    const amountFound = String(expectedAmount).length > 2 && normalized.includes(String(expectedAmount));
    const bankHints = ['bca','bri','bni','mandiri','dana','ovo','gopay','seabank','permata','cimb'].filter(x => text.toLowerCase().includes(x));
    return { text, analysis: { status:'ok', confidence: Math.round(data.confidence || 0), expectedAmount, amountFound, bankHints, recommendation: amountFound ? 'Nominal kemungkinan cocok. Owner tetap perlu verifikasi mutasi.' : 'Nominal belum terbaca/cocok. Periksa manual sebelum ACC.' } };
  } catch (e) {
    return { text:'', analysis:{ status:'error', confidence:0, error:e.message, recommendation:'OCR gagal. Review manual bukti pembayaran.' } };
  }
}
