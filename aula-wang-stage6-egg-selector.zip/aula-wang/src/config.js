import dotenv from 'dotenv';
dotenv.config();
export const config = {
  appName: process.env.APP_NAME || 'AULA WANG',
  appUrl: process.env.APP_URL || 'http://localhost:3000',
  port: Number(process.env.PORT || 3000),
  databaseUrl: process.env.DATABASE_URL,
  sessionSecret: process.env.SESSION_SECRET || 'dev-session-secret',
  jwtSecret: process.env.JWT_SECRET || 'dev-jwt-secret',
  ownerEmail: process.env.OWNER_EMAIL || 'owner@example.com',
  ownerPassword: process.env.OWNER_PASSWORD || 'ChangeMe123!',
  ownerName: process.env.OWNER_NAME || 'Owner AULA WANG',
  payment: {
    bankName: process.env.PAYMENT_BANK_NAME || 'BANK',
    accountNumber: process.env.PAYMENT_ACCOUNT_NUMBER || '',
    accountHolder: process.env.PAYMENT_ACCOUNT_HOLDER || 'AULA WANG',
    instructions: process.env.PAYMENT_INSTRUCTIONS || ''
  },
  reviactyl: {
    enabled: String(process.env.REVIACTYL_SYNC_ENABLED || 'true') === 'true',
    baseUrl: (process.env.REVIACTYL_BASE_URL || '').replace(/\/$/, ''),
    appKey: process.env.REVIACTYL_APPLICATION_API_KEY || '',
    clientKey: process.env.REVIACTYL_CLIENT_API_KEY || '',
    nodeId: Number(process.env.REVIACTYL_DEFAULT_NODE_ID || 1),
    nestId: Number(process.env.REVIACTYL_DEFAULT_NEST_ID || 1),
    eggId: Number(process.env.REVIACTYL_DEFAULT_EGG_ID || 1),
    locationId: Number(process.env.REVIACTYL_DEFAULT_LOCATION_ID || 1),
    allocationId: process.env.REVIACTYL_DEFAULT_ALLOCATION_ID || '',
    image: process.env.REVIACTYL_DEFAULT_DOCKER_IMAGE || 'ghcr.io/pterodactyl/yolks:java_21',
    startup: process.env.REVIACTYL_DEFAULT_STARTUP || 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar'
  },
  ocr: { enabled: String(process.env.OCR_ENABLED || 'true') === 'true', lang: process.env.OCR_LANG || 'eng+ind' },
  backup: { enabled: String(process.env.BACKUP_ENABLED || 'false') === 'true', cron: process.env.BACKUP_CRON || '0 3 * * *' },
  publicStatusEnabled: String(process.env.PUBLIC_STATUS_ENABLED || 'true') === 'true',
  rateLimit: { max:Number(process.env.RATE_LIMIT_MAX || 180), window:process.env.RATE_LIMIT_WINDOW || '1 minute', loginMax:Number(process.env.LOGIN_RATE_LIMIT_MAX || 10) }
};
