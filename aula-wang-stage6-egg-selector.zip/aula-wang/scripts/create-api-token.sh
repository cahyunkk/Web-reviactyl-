#!/usr/bin/env bash
set -euo pipefail
NAME=${1:-bot-integration}
docker compose exec app node src/utils/createApiToken.js "$NAME"
