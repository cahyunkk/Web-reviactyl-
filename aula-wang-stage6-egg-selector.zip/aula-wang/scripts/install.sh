#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker belum ada. Menginstall Docker..."
  curl -fsSL https://get.docker.com | sh
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose plugin tidak ditemukan. Pastikan Docker terbaru terpasang."
  exit 1
fi
[ -f .env ] || cp .env.example .env
read -rp "Domain website (contoh hosting.domainmu.com): " DOMAIN
read -rp "URL Reviactyl Panel (contoh https://panel.domainmu.com): " PANEL_URL
read -rp "Reviactyl Application API Key (ptla_...): " APPKEY
read -rp "Reviactyl Client API Key untuk backup (ptlc_..., boleh kosong): " CLIENTKEY
read -rp "Default Location ID [1]: " LOCATION_ID; LOCATION_ID=${LOCATION_ID:-1}
read -rp "Default Nest ID [1]: " NEST_ID; NEST_ID=${NEST_ID:-1}
read -rp "Default Egg ID [1]: " EGG_ID; EGG_ID=${EGG_ID:-1}
read -rp "Default Node ID [1]: " NODE_ID; NODE_ID=${NODE_ID:-1}
read -rp "Bank pembayaran [BCA]: " BANK; BANK=${BANK:-BCA}
read -rp "Nomor rekening pembayaran: " REK
read -rp "Nama pemilik rekening [AULA WANG]: " REKNAME; REKNAME=${REKNAME:-AULA WANG}
read -rp "Email owner website: " OWNER_EMAIL
read -rsp "Password owner website: " OWNER_PASSWORD; echo
SESSION_SECRET=$(openssl rand -hex 32 2>/dev/null || date +%s%N | sha256sum | cut -d' ' -f1)
JWT_SECRET=$(openssl rand -hex 32 2>/dev/null || date +%s%N | sha256sum | cut -d' ' -f1)
POSTGRES_PASSWORD=$(openssl rand -hex 16 2>/dev/null || date +%s%N | sha256sum | cut -c1-32)
export DOMAIN PANEL_URL APPKEY CLIENTKEY LOCATION_ID NEST_ID EGG_ID NODE_ID BANK REK REKNAME OWNER_EMAIL OWNER_PASSWORD SESSION_SECRET JWT_SECRET POSTGRES_PASSWORD
python3 - <<'PY'
from pathlib import Path
import os
p=Path('.env')
lines=p.read_text().splitlines()
updates={
 'DOMAIN': os.environ['DOMAIN'],
 'APP_URL': 'https://' + os.environ['DOMAIN'],
 'REVIACTYL_BASE_URL': os.environ['PANEL_URL'],
 'REVIACTYL_APPLICATION_API_KEY': os.environ['APPKEY'],
 'REVIACTYL_CLIENT_API_KEY': os.environ['CLIENTKEY'],
 'REVIACTYL_DEFAULT_LOCATION_ID': os.environ['LOCATION_ID'],
 'REVIACTYL_DEFAULT_NEST_ID': os.environ['NEST_ID'],
 'REVIACTYL_DEFAULT_EGG_ID': os.environ['EGG_ID'],
 'REVIACTYL_DEFAULT_NODE_ID': os.environ['NODE_ID'],
 'PAYMENT_BANK_NAME': os.environ['BANK'],
 'PAYMENT_ACCOUNT_NUMBER': os.environ['REK'],
 'PAYMENT_ACCOUNT_HOLDER': os.environ['REKNAME'],
 'OWNER_EMAIL': os.environ['OWNER_EMAIL'],
 'OWNER_PASSWORD': os.environ['OWNER_PASSWORD'],
 'SESSION_SECRET': os.environ['SESSION_SECRET'],
 'JWT_SECRET': os.environ['JWT_SECRET'],
 'POSTGRES_PASSWORD': os.environ['POSTGRES_PASSWORD'],
 'DATABASE_URL': f"postgres://aula:{os.environ['POSTGRES_PASSWORD']}@db:5432/aula_wang",
}
seen=set(); out=[]
for line in lines:
    if '=' in line and not line.strip().startswith('#'):
        k=line.split('=',1)[0].strip()
        if k in updates:
            v=updates[k].replace('\\','\\\\').replace('"','\\"')
            out.append(f'{k}="{v}"')
            seen.add(k)
            continue
    out.append(line)
for k,v in updates.items():
    if k not in seen:
        v=v.replace('\\','\\\\').replace('"','\\"')
        out.append(f'{k}="{v}"')
p.write_text('\n'.join(out)+'\n')
PY
echo "Menjalankan AULA WANG..."
docker compose up -d --build
echo "Selesai. Buka: https://$DOMAIN"
echo "Buat token bot jika perlu: bash scripts/create-api-token.sh discord-bot"
