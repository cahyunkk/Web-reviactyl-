#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p backups
source .env
PG_CONTAINER=$(docker compose ps -q db)
docker exec "$PG_CONTAINER" pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB" > "backups/db-$TS.sql"
tar -czf "backups/files-$TS.tar.gz" uploads .env 2>/dev/null || true
tar -czf "backups/aula-wang-$TS.tar.gz" "backups/db-$TS.sql" "backups/files-$TS.tar.gz"
if [ "${BACKUP_ENABLED:-false}" = "true" ] && [ -n "${RCLONE_REMOTE:-}" ]; then
  docker compose exec -T app rclone copy "/app/backups/aula-wang-$TS.tar.gz" "$RCLONE_REMOTE"
fi
echo "Backup dibuat: backups/aula-wang-$TS.tar.gz"
