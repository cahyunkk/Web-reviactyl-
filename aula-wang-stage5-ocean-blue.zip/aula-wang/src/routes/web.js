import bcrypt from 'bcryptjs';
import sanitizeHtml from 'sanitize-html';
import { q } from '../db/pool.js';
import { signSession, clearSession, requireAuth, requireOwner } from '../middleware/auth.js';
import { config } from '../config.js';
import { invoiceNo, rupiah, dateID } from '../utils/format.js';
import { analyzePaymentProof } from '../services/ocr.js';
import * as reviactyl from '../services/reviactyl.js';
import { notifyOwner, sendEmail } from '../services/notify.js';
import { audit } from '../services/audit.js';
import { createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const clean = (v, max=2000) => sanitizeHtml(String(v || ''), { allowedTags:[], allowedAttributes:{} }).slice(0, max);
const execAsync = promisify(exec);
const csvEscape = v => `"${String(v ?? '').replaceAll('"','""')}"`;

export async function webRoutes(app) {
  app.get('/', async (req, reply) => {
    const pkgs = (await q('SELECT * FROM packages WHERE is_active=true ORDER BY price_monthly')).rows;
    return reply.view('home.ejs', { user:req.user, pkgs, rupiah });
  });

  app.get('/status', async (req, reply) => {
    if (!config.publicStatusEnabled) return reply.code(404).send('Status publik dimatikan');
    const servers = (await q(`SELECT s.name,s.status,s.expires_at,s.reviactyl_identifier,p.name package_name FROM servers s LEFT JOIN packages p ON p.id=s.package_id WHERE s.status IN ('active','expired') ORDER BY s.created_at DESC LIMIT 100`)).rows;
    return reply.view('status.ejs', { user:req.user, servers, dateID });
  });

  app.get('/invoice/:id', { preHandler: requireAuth }, async (req, reply) => {
    const order = req.user.role === 'owner'
      ? (await q('SELECT o.*,u.name user_name,u.email,p.name package_name FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id WHERE o.id=$1', [req.params.id])).rows[0]
      : (await q('SELECT o.*,u.name user_name,u.email,p.name package_name FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id WHERE o.id=$1 AND o.user_id=$2', [req.params.id, req.user.id])).rows[0];
    if (!order) return reply.code(404).send('Invoice tidak ditemukan');
    return reply.view('invoice.ejs', { user:req.user, order, rupiah, dateID, config });
  });

  app.get('/register', async (req, reply) => reply.view('auth.ejs', { user:req.user, mode:'register' }));
  app.post('/register', async (req, reply) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 8) return reply.code(400).view('auth.ejs', { user:req.user, mode:'register', error:'Isi data valid. Password minimal 8 karakter.' });
    const hash = await bcrypt.hash(password, 12);
    try {
      const res = await q('INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4) RETURNING *', [clean(name,120), String(email).toLowerCase(), hash, 'buyer']);
      const user = res.rows[0];
      try { const rid = await reviactyl.createUser(user, password); if (rid) await q('UPDATE users SET reviactyl_user_id=$1 WHERE id=$2', [String(rid), user.id]); } catch(e) { app.log.warn(e, 'sync user reviactyl failed'); }
      signSession(reply, user); return reply.redirect('/dashboard');
    } catch(e) { return reply.code(400).view('auth.ejs', { user:req.user, mode:'register', error:'Email sudah dipakai atau Reviactyl belum siap.' }); }
  });

  app.get('/login', async (req, reply) => reply.view('auth.ejs', { user:req.user, mode:'login' }));
  app.post('/login', async (req, reply) => {
    const { email, password } = req.body;
    const res = await q('SELECT * FROM users WHERE email=$1', [String(email||'').toLowerCase()]);
    const user = res.rows[0];
    if (!user || !(await bcrypt.compare(password||'', user.password_hash))) return reply.code(401).view('auth.ejs', { user:req.user, mode:'login', error:'Email/password salah.' });
    signSession(reply, user); return reply.redirect(user.role === 'owner' ? '/owner' : '/dashboard');
  });
  app.get('/logout', async (req, reply) => { clearSession(reply); reply.redirect('/'); });

  app.get('/dashboard', { preHandler: requireAuth }, async (req, reply) => {
    const [orders, servers, tickets, pkgs] = await Promise.all([
      q('SELECT o.*,p.name package_name FROM orders o LEFT JOIN packages p ON p.id=o.package_id WHERE o.user_id=$1 ORDER BY o.created_at DESC', [req.user.id]),
      q('SELECT s.*,p.name package_name,p.price_monthly,p.memory_mb,p.disk_mb,p.cpu_percent FROM servers s LEFT JOIN packages p ON p.id=s.package_id WHERE s.user_id=$1 ORDER BY s.created_at DESC', [req.user.id]),
      q('SELECT * FROM tickets WHERE user_id=$1 ORDER BY created_at DESC', [req.user.id]),
      q('SELECT * FROM packages WHERE is_active=true ORDER BY price_monthly')
    ]);
    return reply.view('dashboard.ejs', { user:req.user, orders:orders.rows, servers:servers.rows, tickets:tickets.rows, pkgs:pkgs.rows, rupiah, dateID, config });
  });

  app.post('/orders', { preHandler: requireAuth }, async (req, reply) => {
    const { package_id, months='1', type='new' } = req.body;
    const pkg = (await q('SELECT * FROM packages WHERE id=$1 AND is_active=true', [package_id])).rows[0];
    if (!pkg) return reply.code(404).send('Paket tidak ditemukan');
    const m = Math.max(1, Math.min(12, Number(months)||1));
    const amount = pkg.price_monthly * m;
    const inv = invoiceNo();
    const created = (await q('INSERT INTO orders(invoice_no,user_id,package_id,type,months,amount) VALUES($1,$2,$3,$4,$5,$6) RETURNING id', [inv, req.user.id, pkg.id, type, m, amount])).rows[0];
    return reply.redirect(`/orders/${created.id}`);
  });

  app.post('/servers/:id/renew', { preHandler: requireAuth }, async (req, reply) => {
    const server = (await q('SELECT s.*,p.price_monthly FROM servers s JOIN packages p ON p.id=s.package_id WHERE s.id=$1 AND s.user_id=$2', [req.params.id, req.user.id])).rows[0];
    if (!server) return reply.code(404).send('Server tidak ditemukan');
    const m = Math.max(1, Math.min(12, Number(req.body.months)||1));
    const inv = invoiceNo();
    const created = (await q('INSERT INTO orders(invoice_no,user_id,package_id,type,months,amount,server_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id', [inv, req.user.id, server.package_id, 'renew', m, server.price_monthly * m, server.id])).rows[0];
    return reply.redirect(`/orders/${created.id}`);
  });

  app.post('/servers/:id/upgrade', { preHandler: requireAuth }, async (req, reply) => {
    const server = (await q('SELECT * FROM servers WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
    const pkg = (await q('SELECT * FROM packages WHERE id=$1 AND is_active=true', [req.body.package_id])).rows[0];
    if (!server || !pkg) return reply.code(404).send('Server/paket tidak ditemukan');
    if (server.package_id === pkg.id) return reply.redirect('/dashboard');
    const m = Math.max(1, Math.min(12, Number(req.body.months)||1));
    const inv = invoiceNo();
    const created = (await q('INSERT INTO orders(invoice_no,user_id,package_id,type,months,amount,server_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id', [inv, req.user.id, pkg.id, 'upgrade', m, pkg.price_monthly * m, server.id])).rows[0];
    return reply.redirect(`/orders/${created.id}`);
  });


  app.get('/orders/:id', { preHandler: requireAuth }, async (req, reply) => {
    const order = req.user.role === 'owner'
      ? (await q(`SELECT o.*,u.name user_name,u.email,p.name package_name,p.memory_mb,p.disk_mb,p.cpu_percent,p.backups,p.databases,s.name server_name
          FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id LEFT JOIN servers s ON s.id=o.server_id WHERE o.id=$1`, [req.params.id])).rows[0]
      : (await q(`SELECT o.*,u.name user_name,u.email,p.name package_name,p.memory_mb,p.disk_mb,p.cpu_percent,p.backups,p.databases,s.name server_name
          FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id LEFT JOIN servers s ON s.id=o.server_id WHERE o.id=$1 AND o.user_id=$2`, [req.params.id, req.user.id])).rows[0];
    if (!order) return reply.code(404).send('Order tidak ditemukan');
    return reply.view('order_detail.ejs', { user:req.user, order, rupiah, dateID, config });
  });

  app.post('/orders/:id/upload-proof', { preHandler: requireAuth }, async (req, reply) => {
    const order = (await q(`SELECT * FROM orders WHERE id=$1 AND user_id=$2 AND status IN ('pending_payment','rejected','failed')`, [req.params.id, req.user.id])).rows[0];
    if (!order) return reply.code(404).send('Order tidak ditemukan atau status tidak bisa upload ulang');
    const data = await req.file();
    if (!data) return reply.code(400).send('File kosong');
    const ext = path.extname(data.filename || '').toLowerCase() || '.jpg';
    const safe = `${order.invoice_no}-${randomUUID()}${ext}`;
    const dest = path.join(process.cwd(), 'uploads/payment-proofs', safe);
    await pipeline(data.file, createWriteStream(dest));
    const ocr = await analyzePaymentProof(dest, order.amount);
    await q('UPDATE orders SET payment_proof_path=$1, ocr_text=$2, ocr_analysis=$3, status=$4, updated_at=now() WHERE id=$5', [`/uploads/payment-proofs/${safe}`, ocr.text, ocr.analysis, 'payment_uploaded', order.id]);
    await q('INSERT INTO transactions(user_id,order_id,type,amount,status,metadata) VALUES($1,$2,$3,$4,$5,$6)', [req.user.id, order.id, order.type, order.amount, 'payment_uploaded', ocr.analysis]);
    await audit(req.user.id, 'payment_proof_uploaded', 'order', order.id, { invoice:order.invoice_no, amount:order.amount, ocr:ocr.analysis });
    if (String(process.env.NOTIFY_OWNER_ON_PAYMENT || 'true') === 'true') await notifyOwner(app, 'Bukti pembayaran baru', `${req.user.email} upload bukti untuk invoice ${order.invoice_no}`, { amount:rupiah(order.amount), type:order.type, ocr:JSON.stringify(ocr.analysis) });
    return reply.redirect('/dashboard');
  });

  app.post('/tickets', { preHandler: requireAuth }, async (req, reply) => {
    const subject = clean(req.body.subject, 150);
    const message = clean(req.body.message, 2000);
    const t = (await q('INSERT INTO tickets(user_id,subject) VALUES($1,$2) RETURNING *', [req.user.id, subject])).rows[0];
    await q('INSERT INTO ticket_messages(ticket_id,user_id,message) VALUES($1,$2,$3)', [t.id, req.user.id, message]);
    await audit(req.user.id, 'ticket_created', 'ticket', t.id, { subject });
    await notifyOwner(app, 'Tiket baru', `${req.user.email} membuat tiket: ${subject}`);
    return reply.redirect(`/tickets/${t.id}`);
  });

  app.get('/tickets/:id', { preHandler: requireAuth }, async (req, reply) => {
    const params = req.user.role === 'owner' ? [req.params.id] : [req.params.id, req.user.id];
    const sql = req.user.role === 'owner' ? 'SELECT t.*,u.email,u.name user_name FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=$1' : 'SELECT t.*,u.email,u.name user_name FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=$1 AND t.user_id=$2';
    const ticket = (await q(sql, params)).rows[0];
    if (!ticket) return reply.code(404).send('Tiket tidak ditemukan');
    const messages = (await q('SELECT m.*,u.name,u.role FROM ticket_messages m JOIN users u ON u.id=m.user_id WHERE m.ticket_id=$1 ORDER BY m.created_at', [ticket.id])).rows;
    return reply.view('ticket.ejs', { user:req.user, ticket, messages, dateID });
  });

  app.post('/tickets/:id/messages', { preHandler: requireAuth }, async (req, reply) => {
    const ticket = req.user.role === 'owner'
      ? (await q('SELECT * FROM tickets WHERE id=$1', [req.params.id])).rows[0]
      : (await q('SELECT * FROM tickets WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
    if (!ticket) return reply.code(404).send('Tiket tidak ditemukan');
    if (ticket.status === 'closed') return reply.redirect(`/tickets/${ticket.id}`);
    await q('INSERT INTO ticket_messages(ticket_id,user_id,message) VALUES($1,$2,$3)', [ticket.id, req.user.id, clean(req.body.message, 2000)]);
    await q('UPDATE tickets SET updated_at=now() WHERE id=$1', [ticket.id]);
    return reply.redirect(`/tickets/${ticket.id}`);
  });

  app.post('/owner/tickets/:id/close', { preHandler: requireOwner }, async (req, reply) => { await q("UPDATE tickets SET status='closed', updated_at=now() WHERE id=$1", [req.params.id]); reply.redirect(`/tickets/${req.params.id}`); });

  app.get('/owner', { preHandler: requireOwner }, async (req, reply) => {
    const stats = (await q(`SELECT count(*) FILTER (WHERE status='active') active_servers, count(*) orders, coalesce(sum(amount) FILTER (WHERE status IN ('approved','active')),0) revenue FROM orders`)).rows[0];
    const [orders, pkgs, users, tickets, servers, logs] = await Promise.all([
      q('SELECT o.*,u.email,u.name user_name,p.name package_name FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id ORDER BY o.created_at DESC LIMIT 100'),
      q('SELECT * FROM packages ORDER BY price_monthly'),
      q('SELECT id,name,email,role,reviactyl_user_id,created_at FROM users ORDER BY created_at DESC LIMIT 100'),
      q('SELECT t.*,u.email FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.created_at DESC LIMIT 50'),
      q('SELECT s.*,u.email,p.name package_name FROM servers s JOIN users u ON u.id=s.user_id LEFT JOIN packages p ON p.id=s.package_id ORDER BY s.created_at DESC LIMIT 100'),
      q('SELECT l.*,u.email FROM activity_logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT 50')
    ]);
    return reply.view('owner.ejs', { user:req.user, stats, orders:orders.rows, pkgs:pkgs.rows, users:users.rows, tickets:tickets.rows, servers:servers.rows, logs:logs.rows, rupiah, dateID, config });
  });

  app.get('/owner/reports/sales.csv', { preHandler: requireOwner }, async (req, reply) => {
    const rows = (await q(`SELECT o.invoice_no,o.type,o.amount,o.status,o.created_at,u.email,p.name package_name FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN packages p ON p.id=o.package_id ORDER BY o.created_at DESC`)).rows;
    const header = ['invoice_no','type','amount','status','created_at','email','package_name'];
    const csv = [header.join(','), ...rows.map(r => header.map(h => csvEscape(r[h])).join(','))].join('\n');
    await audit(req.user.id, 'sales_csv_exported', 'report', '', { rows:rows.length });
    return reply.header('Content-Type','text/csv; charset=utf-8').header('Content-Disposition','attachment; filename="aula-wang-sales.csv"').send(csv);
  });

  app.post('/owner/backup-website', { preHandler: requireOwner }, async (req, reply) => {
    try {
      const { stdout, stderr } = await execAsync('bash scripts/backup.sh', { cwd: process.cwd(), timeout: 10 * 60 * 1000 });
      await audit(req.user.id, 'website_backup_requested', 'backup', '', { stdout: stdout.slice(-500), stderr: stderr.slice(-500) });
    } catch(e) {
      await audit(req.user.id, 'website_backup_failed', 'backup', '', { error:e.message });
      app.log.error(e, 'manual website backup failed');
    }
    return reply.redirect('/owner');
  });

  app.post('/owner/packages', { preHandler: requireOwner }, async (req, reply) => {
    const b=req.body; await q('INSERT INTO packages(name,description,price_monthly,memory_mb,disk_mb,cpu_percent,backups,databases,is_active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)', [clean(b.name,120),clean(b.description,500),b.price_monthly,b.memory_mb,b.disk_mb,b.cpu_percent,b.backups||1,b.databases||0,!!b.is_active]); return reply.redirect('/owner');
  });

  app.post('/owner/packages/:id/update', { preHandler: requireOwner }, async (req, reply) => {
    const b=req.body;
    await q('UPDATE packages SET name=$1,description=$2,price_monthly=$3,memory_mb=$4,disk_mb=$5,cpu_percent=$6,backups=$7,databases=$8,is_active=$9 WHERE id=$10', [clean(b.name,120),clean(b.description,500),b.price_monthly,b.memory_mb,b.disk_mb,b.cpu_percent,b.backups||1,b.databases||0,!!b.is_active,req.params.id]);
    await audit(req.user.id, 'package_updated', 'package', req.params.id, { name:b.name });
    return reply.redirect('/owner');
  });

  app.post('/owner/packages/:id/delete', { preHandler: requireOwner }, async (req, reply) => {
    await q('UPDATE packages SET is_active=false WHERE id=$1', [req.params.id]);
    await audit(req.user.id, 'package_disabled', 'package', req.params.id, {});
    return reply.redirect('/owner');
  });

  app.post('/owner/users/:id/role', { preHandler: requireOwner }, async (req, reply) => {
    const role = req.body.role === 'owner' ? 'owner' : 'buyer';
    if (req.params.id !== req.user.id) await q('UPDATE users SET role=$1, updated_at=now() WHERE id=$2', [role, req.params.id]);
    return reply.redirect('/owner');
  });

  app.post('/owner/users/:id/update', { preHandler: requireOwner }, async (req, reply) => {
    await q('UPDATE users SET name=$1,email=$2,reviactyl_user_id=$3,updated_at=now() WHERE id=$4', [clean(req.body.name,120), String(req.body.email||'').toLowerCase(), clean(req.body.reviactyl_user_id,80), req.params.id]);
    await audit(req.user.id, 'user_updated', 'user', req.params.id, {});
    return reply.redirect('/owner');
  });

  app.post('/owner/orders/:id/reject', { preHandler: requireOwner }, async (req, reply) => { await q('UPDATE orders SET status=$1,owner_note=$2,updated_at=now() WHERE id=$3', ['rejected', clean(req.body.owner_note,500), req.params.id]); await audit(req.user.id, 'order_rejected', 'order', req.params.id, { note:req.body.owner_note }); reply.redirect('/owner'); });

  app.post('/owner/orders/:id/approve', { preHandler: requireOwner }, async (req, reply) => {
    const order = (await q(`SELECT
      o.id order_id,o.invoice_no,o.user_id,o.package_id,o.type,o.months,o.amount,o.server_id existing_server_id,
      u.name user_name,u.email,u.reviactyl_user_id,
      p.name package_name,p.description package_description,p.price_monthly,p.memory_mb,p.disk_mb,p.cpu_percent,p.backups,p.databases
      FROM orders o JOIN users u ON u.id=o.user_id JOIN packages p ON p.id=o.package_id WHERE o.id=$1`, [req.params.id])).rows[0];
    if (!order) return reply.code(404).send('Order tidak ditemukan');
    await q('UPDATE orders SET status=$1,updated_at=now() WHERE id=$2', ['provisioning', order.order_id]);
    try {
      if (order.type === 'new') {
        if (!order.reviactyl_user_id) throw new Error('User belum punya reviactyl_user_id. Sinkronisasi user dulu atau isi manual di database.');
        const server = await reviactyl.createServer({ user:{ name:order.user_name, email:order.email, reviactyl_user_id:order.reviactyl_user_id }, pkg: order, order });
        const local = (await q('INSERT INTO servers(user_id,package_id,order_id,name,reviactyl_server_id,reviactyl_identifier,status,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,now() + ($8 ||\' months\')::interval) RETURNING *', [order.user_id, order.package_id, order.order_id, `${order.user_name} - ${order.package_name}`, String(server.id||''), server.identifier||'', 'active', order.months])).rows[0];
        await q('UPDATE orders SET status=$1,server_id=$2,updated_at=now() WHERE id=$3', ['active', local.id, order.order_id]);
      } else if (order.type === 'renew') {
        const srv = (await q('UPDATE servers SET status=$1, expires_at = greatest(coalesce(expires_at, now()), now()) + ($2 ||\' months\')::interval, updated_at=now() WHERE id=$3 AND user_id=$4 RETURNING *', ['active', order.months, order.existing_server_id, order.user_id])).rows[0];
        if (!srv) throw new Error('Server untuk renew tidak ditemukan');
        if (srv.reviactyl_server_id) { try { await reviactyl.unsuspendServer(srv.reviactyl_server_id); } catch(e) { app.log.warn(e, 'unsuspend failed/non fatal'); } }
        await q('UPDATE orders SET status=$1,updated_at=now() WHERE id=$2', ['active', order.order_id]);
      } else if (order.type === 'upgrade') {
        const srv = (await q('SELECT * FROM servers WHERE id=$1 AND user_id=$2', [order.existing_server_id, order.user_id])).rows[0];
        if (!srv) throw new Error('Server untuk upgrade tidak ditemukan');
        if (srv.reviactyl_server_id) await reviactyl.updateServerBuild(srv.reviactyl_server_id, order);
        await q('UPDATE servers SET package_id=$1,status=$2,updated_at=now() WHERE id=$3', [order.package_id, 'active', srv.id]);
        await q('UPDATE orders SET status=$1,updated_at=now() WHERE id=$2', ['active', order.order_id]);
      }
      await q('INSERT INTO transactions(user_id,order_id,type,amount,status) VALUES($1,$2,$3,$4,$5)', [order.user_id, order.order_id, order.type, order.amount, 'approved']);
      await audit(req.user.id, 'order_approved', 'order', order.order_id, { invoice:order.invoice_no, type:order.type });
      try { await sendEmail({ to:order.email, subject:`Invoice ${order.invoice_no} disetujui`, text:`Pembayaran Anda sudah disetujui. Order ${order.type} telah diproses.` }); } catch(e) { app.log.warn(e, 'buyer email failed'); }
    } catch(e) { await q('UPDATE orders SET status=$1,owner_note=$2,updated_at=now() WHERE id=$3', ['failed', e.message, order.order_id]); }
    return reply.redirect('/owner');
  });

  app.post('/owner/servers/:id/backup', { preHandler: requireOwner }, async (req, reply) => {
    const srv = (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0];
    if (!srv) return reply.code(404).send('Server tidak ditemukan');
    try {
      if (!srv.reviactyl_identifier) throw new Error('Identifier Reviactyl kosong');
      await reviactyl.createBackup(srv.reviactyl_identifier);
      await q('UPDATE servers SET updated_at=now() WHERE id=$1', [srv.id]);
      await audit(req.user.id, 'server_backup_requested', 'server', srv.id, { identifier:srv.reviactyl_identifier });
    } catch(e) { app.log.error(e, 'server backup failed'); }
    return reply.redirect('/owner');
  });

  app.get('/servers/:id/status.json', { preHandler: requireAuth }, async (req, reply) => {
    const srv = req.user.role === 'owner'
      ? (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0]
      : (await q('SELECT * FROM servers WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id])).rows[0];
    if (!srv) return reply.code(404).send({ error:'server not found' });
    const out = { local:srv, application:null, resources:null, errors:[] };
    if (srv.reviactyl_server_id) {
      try { out.application = await reviactyl.getServer(srv.reviactyl_server_id); } catch(e) { out.errors.push(`application: ${e.message}`); }
    }
    if (srv.reviactyl_identifier) {
      try { out.resources = await reviactyl.getServerResources(srv.reviactyl_identifier); } catch(e) { out.errors.push(`resources: ${e.message}`); }
    }
    return reply.send(out);
  });

  app.post('/owner/servers/:id/power', { preHandler: requireOwner }, async (req, reply) => {
    const srv = (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0];
    const signal = String(req.body.signal || 'restart');
    if (!srv) return reply.code(404).send('Server tidak ditemukan');
    try {
      if (!srv.reviactyl_identifier) throw new Error('Identifier Reviactyl kosong');
      await reviactyl.powerAction(srv.reviactyl_identifier, signal);
      await audit(req.user.id, 'server_power_action', 'server', srv.id, { signal });
    } catch(e) { await audit(req.user.id, 'server_power_failed', 'server', srv.id, { signal, error:e.message }); app.log.error(e, 'server power failed'); }
    return reply.redirect('/owner');
  });

  app.post('/owner/servers/:id/suspend', { preHandler: requireOwner }, async (req, reply) => {
    const srv = (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0];
    if (!srv) return reply.code(404).send('Server tidak ditemukan');
    try { if (srv.reviactyl_server_id) await reviactyl.suspendServer(srv.reviactyl_server_id); await q("UPDATE servers SET status='suspended', updated_at=now() WHERE id=$1", [srv.id]); await audit(req.user.id, 'server_suspended', 'server', srv.id, {}); } catch(e) { app.log.error(e, 'suspend failed'); }
    return reply.redirect('/owner');
  });

  app.post('/owner/servers/:id/unsuspend', { preHandler: requireOwner }, async (req, reply) => {
    const srv = (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0];
    if (!srv) return reply.code(404).send('Server tidak ditemukan');
    try { if (srv.reviactyl_server_id) await reviactyl.unsuspendServer(srv.reviactyl_server_id); await q("UPDATE servers SET status='active', updated_at=now() WHERE id=$1", [srv.id]); await audit(req.user.id, 'server_unsuspended', 'server', srv.id, {}); } catch(e) { app.log.error(e, 'unsuspend failed'); }
    return reply.redirect('/owner');
  });

  app.post('/owner/servers/:id/reinstall', { preHandler: requireOwner }, async (req, reply) => {
    const srv = (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0];
    if (!srv) return reply.code(404).send('Server tidak ditemukan');
    try { if (!srv.reviactyl_server_id) throw new Error('Reviactyl server ID kosong'); await reviactyl.reinstallServer(srv.reviactyl_server_id); await audit(req.user.id, 'server_reinstall_requested', 'server', srv.id, {}); } catch(e) { app.log.error(e, 'reinstall failed'); }
    return reply.redirect('/owner');
  });

  app.post('/owner/servers/:id/delete', { preHandler: requireOwner }, async (req, reply) => {
    const srv = (await q('SELECT * FROM servers WHERE id=$1', [req.params.id])).rows[0];
    if (!srv) return reply.code(404).send('Server tidak ditemukan');
    if (req.body.confirm !== 'DELETE') return reply.redirect('/owner');
    try {
      if (srv.reviactyl_server_id) {
        try { await reviactyl.deleteServer(srv.reviactyl_server_id); } catch(e) { await reviactyl.forceDeleteServer(srv.reviactyl_server_id); }
      }
      await q("UPDATE servers SET status='deleted', updated_at=now() WHERE id=$1", [srv.id]);
      await audit(req.user.id, 'server_deleted', 'server', srv.id, { reviactyl_server_id:srv.reviactyl_server_id });
    } catch(e) { await audit(req.user.id, 'server_delete_failed', 'server', srv.id, { error:e.message }); app.log.error(e, 'delete server failed'); }
    return reply.redirect('/owner');
  });

}
